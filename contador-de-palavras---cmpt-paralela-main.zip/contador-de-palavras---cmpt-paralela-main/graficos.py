import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(r"csv_analys\resultados.csv")

df["tempo_ms"] = pd.to_numeric(df["tempo_ms"], errors="coerce")

textos = df["texto"].unique()

for texto in textos:
    df_texto = df[df["texto"] == texto]

    plt.figure(figsize=(12, 6))
    df_texto.groupby("tipo_de_execucao")["tempo_ms"].mean().plot(kind="bar")

    plt.title(f"Tempos de execução para o texto: {texto}")
    plt.xlabel("Tipo de execução")
    plt.ylabel("Tempo (ms)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.show()

for palavra in df["palavra_procurada"].unique():
    df_palavra = df[df["palavra_procurada"] == palavra]

    plt.figure(figsize=(12, 6))
    plt.bar(df_palavra["tipo_de_execucao"], df_palavra["tempo_ms"])
    plt.title(f"Comparação de execução para a palavra: {palavra}")
    plt.xlabel("Tipo de execução")
    plt.ylabel("Tempo (ms)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.show()

pivot = df.pivot_table(index="palavra_procurada",
                       columns="tipo_de_execucao",
                       values="tempo_ms")

plt.figure(figsize=(12, 6))
pivot.plot(marker="o")
plt.title("Comparação das execuções por palavra")
plt.xlabel("Palavra procurada")
plt.ylabel("Tempo (ms)")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.show()