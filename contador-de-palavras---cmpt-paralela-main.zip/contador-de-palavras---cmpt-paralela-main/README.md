Análise comparativa de algoritmos com uso de paralelismo

Autor 1: Guilherme Braga
Autor 2: Miguel Tacchi
________________________________________
Resumo
Este relatório apresenta um estudo comparativo entre algoritmos de contagem de palavras implementados em ambientes seriais e paralelos utilizando Java. Foram desenvolvidas três abordagens: uma versão serial na CPU, uma versão paralela utilizando Thread Pools e uma versão paralela com processamento na GPU por meio de OpenCL (JOCL). Os testes foram realizados utilizando arquivos de texto de diferentes tamanhos, e os tempos de execução foram registrados em arquivos CSV para posterior análise gráfica. Os resultados demonstram diferenças significativas entre as abordagens, evidenciando o impacto do paralelismo e da arquitetura de hardware no desempenho final.
________________________________________
Introdução
A busca por eficiência computacional é um dos pilares da computação moderna, principalmente em aplicações que manipulam grandes massas de dados. O uso de múltiplos núcleos de CPU e unidades de processamento gráfico (GPU) oferece oportunidades para ganhos de desempenho por meio de paralelismo.
Este trabalho analisa três métodos de contagem de ocorrências de palavras em textos:
•	SerialCPU: execução sequencial utilizando um único thread.
•	ParallelCPU: paralelização por meio de Thread Pools, dividindo o texto em segmentos processados simultaneamente.
•	ParallelGPU: execução massivamente paralela na GPU utilizando kernels OpenCL através da biblioteca JOCL.
O objetivo é comparar o desempenho dessas abordagens sob diferentes tamanhos de entrada e configurações de paralelismo.
________________________________________
Metodologia
A metodologia consistiu em implementar, executar e comparar os três métodos de contagem de palavras descritos anteriormente. O processo envolveu:
Implementação
•	Desenvolvimento das versões SerialCPU, ParallelCPU e ParallelGPU em Java.
•	Utilização da biblioteca JOCL 2.0.4 para execução de kernels OpenCL.
Execução Repetida
•	Cada teste foi executado pelo menos três vezes para minimizar variações e assegurar consistência estatística.
•	Foram utilizados arquivos de texto de tamanhos distintos (Dracula, Don Quixote e Moby Dick).
Registro de Dados
•	Os resultados coletados (tempo de execução em milissegundos e número de ocorrências) foram registrados em arquivos CSV.
Análise
•	A partir dos CSVs, foram gerados gráficos comparativos considerando:
o	Serial vs ParallelCPU
o	Serial vs ParallelGPU
o	Variação de threads no ParallelCPU
•	A análise focou em identificar padrões, gargalos e escalabilidade dos métodos.
________________________________________
Resultados e Discussão
Os experimentos revelaram comportamentos distintos entre as abordagens de CPU e GPU.
Paralelismo em CPU (Thread Pools)
•	A abordagem ParallelCPU apresentou o melhor desempenho geral.
•	Aumentar o número de threads reduziu significativamente o tempo de execução até certo limite, onde o ganho se estabiliza.
•	No texto Don Quixote, por exemplo, a execução serial levou cerca de 400 ms, enquanto a paralela com 10 threads ficou abaixo de 100 ms, representando um speedup de aproximadamente 4 vezes.
•	Em textos menores (Dracula e Moby Dick), o ParallelCPU manteve resultados entre 20 ms e 50 ms, superando consistentemente a versão serial.
Paralelismo em GPU (JOCL)
•	A versão ParallelGPU apresentou os piores tempos em todos os testes.
•	Os tempos variaram entre 500 ms e mais de 800 ms.
•	O alto overhead de transferência de dados entre CPU e GPU, além da compilação dos kernels e alocação de buffers, tornou a GPU ineficiente para essa tarefa.
•	A GPU seria mais adequada para operações matemáticas complexas ou arquivos extremamente grandes (ordem de gigabytes).
Execução Serial
•	A abordagem SerialCPU serviu como baseline.
•	Embora mais lenta que a versão paralela em CPU, ainda foi muito mais rápida que a versão em GPU.
•	Os resultados indicam que à medida que o texto cresce, o benefício do multithreading aumenta, evidenciando a escalabilidade da abordagem paralela em CPU.
________________________________________
Conclusão
Para a tarefa de contagem de palavras, o paralelismo na CPU mostrou ser a abordagem mais eficiente. A versão SerialCPU apresentou desempenho previsível, porém inferior à versão paralela. Já a abordagem ParallelGPU foi prejudicada pelo alto custo de comunicação e inicialização, tornando-se inadequada para esse tipo de processamento.
Conclui-se que o uso de multithreading em CPU é a melhor solução para problemas envolvendo processamento de texto de tamanho moderado, enquanto o uso da GPU só seria vantajoso para conjuntos de dados muito maiores ou cálculos significativamente mais complexos.
________________________________________
Referências
•	Biblioteca JOCL 2.0.4
•	Amostras fornecidas na atividade
•	Documentação oficial do OpenCL
________________________________________
Anexos
Os códigos completos das versões SerialCPU, ParallelCPU e ParallelGPU, bem como os kernels OpenCL, encontram-se no repositório:
https://github.com/GuilhermeBrga/contador-de-palavras---cmpt-paralela.git
