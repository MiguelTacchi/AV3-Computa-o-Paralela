package Parallel_GPU;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.jocl.*;

public class Read_txt {

    public Read_txt() {
        CL.setExceptionsEnabled(true);
    }

    public long lerArquivo(String caminhoArquivo, String palavraBuscada) {
        long inicioTotal = System.currentTimeMillis();

        // ---- 1) Ler e tokenizar ----
        List<String> tokens = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(caminhoArquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {

                // ----------------------------------------------------------------------------------
                // CORREÇÃO: Usar a expressão regular dos códigos anteriores
                // Remove todos os caracteres que não sejam letras (acentuadas/não acentuadas),
                // números ou espaços, substituindo-os por uma string vazia (""),
                // e depois converte para minúsculas.
                // ----------------------------------------------------------------------------------
                String limpa = linha.replaceAll("[^a-zA-Z0-9áéíóúàâêôãõçÁÉÍÓÚÀÂÊÔÃÕÇ ]", "")
                        .toLowerCase();

                String[] partes = limpa.split("\\s+");
                for (String p : partes) {
                    if (!p.isBlank()) tokens.add(p);
                }
            }
        } catch (IOException e) {
            System.err.println("Erro: " + e.getMessage());
            return -1;
        }

        if (tokens.isEmpty()) {
            System.out.println("Nenhum token válido.");
            return -1;
        }

        // ---- 2) Empacotar tokens ----
        List<byte[]> tokenBytesList = new ArrayList<>(tokens.size());
        int totalBytes = 0;
        for (String t : tokens) {
            byte[] b = t.getBytes(StandardCharsets.UTF_8);
            tokenBytesList.add(b);
            totalBytes += b.length;
        }

        byte[] data = new byte[totalBytes];
        int[] offsets = new int[tokens.size()];
        int[] lengths = new int[tokens.size()];

        int pos = 0;
        for (int i = 0; i < tokenBytesList.size(); i++) {
            byte[] b = tokenBytesList.get(i);
            offsets[i] = pos;
            lengths[i] = b.length;
            System.arraycopy(b, 0, data, pos, b.length);
            pos += b.length;
        }

        // ---- 3) Preparar palavra buscada ----
        byte[] targetWord = palavraBuscada.toLowerCase().getBytes(StandardCharsets.UTF_8);
        int targetLen = targetWord.length;
        long targetHash = djb2Hash(targetWord);

        // ---- 4) GPU ----
        int numWords = tokens.size();
        int resultCount = runOpenCLCount(data, offsets, lengths,
                targetWord, targetLen, targetHash, numWords);

        long fimTotal = System.currentTimeMillis();
        long tempoTotal = fimTotal - inicioTotal;

        System.out.println(palavraBuscada + " - " + resultCount +
                " ocorrencias em " + tempoTotal + " ms usando GPU\n");

        return tempoTotal;
    }

    private static long djb2Hash(byte[] bytes) {
        long hash = 5381L;
        for (byte b : bytes) {
            int ub = b & 0xFF;
            hash = ((hash << 5) + hash) + ub;
        }
        return hash;
    }


    // ------------------------------------------------------------------------
    //  GPU – Versão sem colisões (hash + verificação byte-a-byte)
    //  O Kernel OpenCL não foi alterado, pois sua lógica é correta.
    // ------------------------------------------------------------------------
    private int runOpenCLCount(byte[] data, int[] offsets, int[] lengths,
                               byte[] targetWord, int targetLen,
                               long targetHash, int numWords) {

        final String programSource =
                "__kernel void count_hashes(\n" +
                        "    __global const uchar* data,\n" +
                        "    __global const int* offsets,\n" +
                        "    __global const int* lengths,\n" +
                        "    __global const uchar* target_word,\n" +
                        "    const int target_len,\n" +
                        "    const ulong target_hash,\n" +
                        "    __global int* result)\n" +
                        "{\n" +
                        "    int gid = get_global_id(0);\n" +
                        "    int total = get_global_size(0);\n" +
                        "    if (gid >= total) return;\n" +
                        "\n" +
                        "    int off = offsets[gid];\n" +
                        "    int len = lengths[gid];\n" +
                        "\n" +
                        "    // 1) Calcula hash\n" +
                        "    ulong hash = 5381ul;\n" +
                        "    for (int i = 0; i < len; i++) {\n" +
                        "        hash = ((hash << 5) + hash) + (ulong)data[off + i];\n" +
                        "    }\n" +
                        "\n" +
                        "    if (hash != target_hash) return;\n" +
                        "\n" +
                        "    // 2) Verificação exata\n" +
                        "    if (len != target_len) return;\n" +
                        "    for (int i = 0; i < len; i++) {\n" +
                        "        if (data[off + i] != target_word[i]) return;\n" +
                        "    }\n" +
                        "\n" +
                        "    // 3) Igual = conta\n" +
                        "    atomic_add(&result[0], 1);\n" +
                        "}";

        // Plataformas
        int[] numPlatformsArray = new int[1];
        CL.clGetPlatformIDs(0, null, numPlatformsArray);
        cl_platform_id[] platforms = new cl_platform_id[numPlatformsArray[0]];
        CL.clGetPlatformIDs(platforms.length, platforms, null);

        cl_platform_id platform = null;
        cl_device_id device = null;

        // Tentar GPU
        for (cl_platform_id p : platforms) {
            int[] numDevices = new int[1];
            int err = CL.clGetDeviceIDs(p, CL.CL_DEVICE_TYPE_GPU, 0, null, numDevices);
            if (err == CL.CL_SUCCESS && numDevices[0] > 0) {
                cl_device_id[] devs = new cl_device_id[numDevices[0]];
                CL.clGetDeviceIDs(p, CL.CL_DEVICE_TYPE_GPU, devs.length, devs, null);
                platform = p;
                device = devs[0];
                break;
            }
        }

        // Se não houver GPU → CPU
        if (device == null) {
            for (cl_platform_id p : platforms) {
                int[] numDevices = new int[1];
                int err = CL.clGetDeviceIDs(p, CL.CL_DEVICE_TYPE_CPU, 0, null, numDevices);
                if (err == CL.CL_SUCCESS && numDevices[0] > 0) {
                    cl_device_id[] devs = new cl_device_id[numDevices[0]];
                    CL.clGetDeviceIDs(p, CL.CL_DEVICE_TYPE_CPU, devs.length, devs, null);
                    platform = p;
                    device = devs[0];
                    break;
                }
            }
        }

        // Contexto
        cl_context_properties props = new cl_context_properties();
        props.addProperty(CL.CL_CONTEXT_PLATFORM, platform);

        cl_context context = CL.clCreateContext(
                props, 1, new cl_device_id[]{device}, null, null, null);

        cl_command_queue commandQueue =
                CL.clCreateCommandQueueWithProperties(context, device, null, null);

        // Buffers
        cl_mem dataMem = CL.clCreateBuffer(context,
                CL.CL_MEM_READ_ONLY | CL.CL_MEM_COPY_HOST_PTR,
                Sizeof.cl_uchar * data.length, Pointer.to(data), null);

        cl_mem offsetsMem = CL.clCreateBuffer(context,
                CL.CL_MEM_READ_ONLY | CL.CL_MEM_COPY_HOST_PTR,
                Sizeof.cl_int * offsets.length, Pointer.to(offsets), null);

        cl_mem lengthsMem = CL.clCreateBuffer(context,
                CL.CL_MEM_READ_ONLY | CL.CL_MEM_COPY_HOST_PTR,
                Sizeof.cl_int * lengths.length, Pointer.to(lengths), null);

        cl_mem targetWordMem = CL.clCreateBuffer(context,
                CL.CL_MEM_READ_ONLY | CL.CL_MEM_COPY_HOST_PTR,
                Sizeof.cl_uchar * targetWord.length, Pointer.to(targetWord), null);

        // Resultado
        int[] resultHost = new int[]{0};
        cl_mem resultMem = CL.clCreateBuffer(context,
                CL.CL_MEM_READ_WRITE | CL.CL_MEM_COPY_HOST_PTR,
                Sizeof.cl_int, Pointer.to(resultHost), null);

        // Programa
        cl_program program = CL.clCreateProgramWithSource(context, 1,
                new String[]{programSource}, null, null);

        int buildErr = CL.clBuildProgram(program, 0, null, null, null, null);
        if (buildErr != CL.CL_SUCCESS) {
            long[] logSize = new long[1];
            CL.clGetProgramBuildInfo(program, device, CL.CL_PROGRAM_BUILD_LOG,
                    0, null, logSize);
            byte[] logData = new byte[(int) logSize[0]];
            CL.clGetProgramBuildInfo(program, device, CL.CL_PROGRAM_BUILD_LOG,
                    logSize[0], Pointer.to(logData), null);
            throw new RuntimeException("Erro ao compilar kernel:\n" +
                    new String(logData));
        }

        cl_kernel kernel = CL.clCreateKernel(program, "count_hashes", null);

        // Args
        CL.clSetKernelArg(kernel, 0, Sizeof.cl_mem, Pointer.to(dataMem));
        CL.clSetKernelArg(kernel, 1, Sizeof.cl_mem, Pointer.to(offsetsMem));
        CL.clSetKernelArg(kernel, 2, Sizeof.cl_mem, Pointer.to(lengthsMem));
        CL.clSetKernelArg(kernel, 3, Sizeof.cl_mem, Pointer.to(targetWordMem));
        CL.clSetKernelArg(kernel, 4, Sizeof.cl_int, Pointer.to(new int[]{targetLen}));

        ByteBuffer hashBuffer = ByteBuffer.allocateDirect(8).order(ByteOrder.nativeOrder());
        hashBuffer.putLong(targetHash).rewind();
        CL.clSetKernelArg(kernel, 5, Sizeof.cl_ulong, Pointer.to(hashBuffer));

        CL.clSetKernelArg(kernel, 6, Sizeof.cl_mem, Pointer.to(resultMem));

        long[] globalWorkSize = new long[]{numWords};

        // Execução
        CL.clEnqueueNDRangeKernel(commandQueue, kernel, 1,
                null, globalWorkSize, null, 0, null, null);

        // Ler resultado
        CL.clEnqueueReadBuffer(commandQueue, resultMem, CL.CL_TRUE,
                0, Sizeof.cl_int, Pointer.to(resultHost), 0, null, null);

        // Libera
        CL.clReleaseKernel(kernel);
        CL.clReleaseProgram(program);
        CL.clReleaseMemObject(dataMem);
        CL.clReleaseMemObject(offsetsMem);
        CL.clReleaseMemObject(lengthsMem);
        CL.clReleaseMemObject(targetWordMem);
        CL.clReleaseMemObject(resultMem);
        CL.clReleaseCommandQueue(commandQueue);
        CL.clReleaseContext(context);

        return resultHost[0];
    }
}