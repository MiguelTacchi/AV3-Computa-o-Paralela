import java.util.ArrayList;
import java.util.Scanner;

import Csv.Csv_gen;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String[] paths = {
                "C:\\Users\\guilh\\IdeaProjects\\word_counter\\src\\data\\DonQuixote-388208.txt",
                "C:\\Users\\guilh\\IdeaProjects\\word_counter\\src\\data\\Dracula-165307.txt",
                "C:\\Users\\guilh\\IdeaProjects\\word_counter\\src\\data\\MobyDick-217452.txt"
        };

        String[] nomes_paths = {"Don quixote", "Dracula", "MobyDick"};

        ArrayList<String> dados = new ArrayList<>();

        Serial.Read_txt rt_serial = new Serial.Read_txt();
        Parallel.Read_txt rt_paralelo2 = new Parallel.Read_txt(2);
        Parallel.Read_txt rt_paralelo4 = new Parallel.Read_txt(4);
        Parallel.Read_txt rt_paralelo6 = new Parallel.Read_txt(6);
        Parallel.Read_txt rt_paralelo8 = new Parallel.Read_txt(8);
        Parallel.Read_txt rt_paralelo10 = new Parallel.Read_txt(10);
        Parallel_GPU.Read_txt rt_gpu = new Parallel_GPU.Read_txt();

        System.out.println("Execução serial: ");

        for (int i = 0; i < 3; i++) {
            System.out.print("Digite a palavra a ser buscada no arquivo (" + nomes_paths[i] + "): ");
            String palavra_txt = sc.next();

            dados.add("Serial");
            dados.add(nomes_paths[i]);
            dados.add(String.valueOf(rt_serial.lerArquivo(paths[i], palavra_txt)));
        }

        System.out.println("Execução paralela (2 threads): ");

        for (int i = 0; i < 3; i++) {
            System.out.print("Digite a palavra a ser buscada no arquivo (" + nomes_paths[i] + "): ");
            String palavra_txt = sc.next();

            dados.add("Paralelo (2 threads)");
            dados.add(nomes_paths[i]);
            dados.add(String.valueOf(rt_paralelo2.lerArquivo(paths[i], palavra_txt)));
        }

        System.out.println("Execução paralela (4 threads): ");

        for (int i = 0; i < 3; i++) {
            System.out.print("Digite a palavra a ser buscada no arquivo (" + nomes_paths[i] + "): ");
            String palavra_txt = sc.next();

            dados.add("Paralelo (4 threads)");
            dados.add(nomes_paths[i]);
            dados.add(String.valueOf(rt_paralelo4.lerArquivo(paths[i], palavra_txt)));
        }

        System.out.println("Execução paralela (6 threads): ");

        for (int i = 0; i < 3; i++) {
            System.out.print("Digite a palavra a ser buscada no arquivo (" + nomes_paths[i] + "): ");
            String palavra_txt = sc.next();

            dados.add("Paralelo (6 threads)");
            dados.add(nomes_paths[i]);
            dados.add(String.valueOf(rt_paralelo6.lerArquivo(paths[i], palavra_txt)));
        }

        System.out.println("Execução paralela (8 threads): ");

        for (int i = 0; i < 3; i++) {
            System.out.print("Digite a palavra a ser buscada no arquivo (" + nomes_paths[i] + "): ");
            String palavra_txt = sc.next();

            dados.add("Paralelo (8 threads)");
            dados.add(nomes_paths[i]);
            dados.add(String.valueOf(rt_paralelo8.lerArquivo(paths[i], palavra_txt)));
        }

        System.out.println("Execução paralela (10 threads): ");

        for (int i = 0; i < 3; i++) {
            System.out.print("Digite a palavra a ser buscada no arquivo (" + nomes_paths[i] + "): ");
            String palavra_txt = sc.next();

            dados.add("Paralelo (10 threads)");
            dados.add(nomes_paths[i]);
            dados.add(String.valueOf(rt_paralelo10.lerArquivo(paths[i], palavra_txt)));
        }

        System.out.println("Execução paralela (GPU): ");

        for (int i = 0; i < 3; i++) {
            System.out.print("Digite a palavra a ser buscada no arquivo (" + nomes_paths[i] + "): ");
            String palavra_txt = sc.next();

            dados.add("Paralelo (GPU)");
            dados.add(nomes_paths[i]);
            dados.add(String.valueOf(rt_gpu.lerArquivo(paths[i], palavra_txt)));
        }

        new Csv_gen(dados).gerarCSV("resultado.csv");

        System.out.println(dados);
    }
}
