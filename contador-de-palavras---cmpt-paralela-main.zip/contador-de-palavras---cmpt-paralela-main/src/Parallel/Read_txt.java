package Parallel;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class Read_txt {

    private final int numThreads;

    public Read_txt(int numThreads) {
        this.numThreads = numThreads;
    }

    public int lerArquivo(String caminhoArquivo, String palavraBuscada) {

        long inicio = System.currentTimeMillis();

        List<String> linhas = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(caminhoArquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                linhas.add(linha);
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        }

        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        List<Future<Integer>> resultados = new ArrayList<>();

        int totalLinhas = linhas.size();
        int bloco = totalLinhas / numThreads;

        for (int i = 0; i < numThreads; i++) {

            int inicioBloco = i * bloco;
            int fimBloco = (i == numThreads - 1) ? totalLinhas : inicioBloco + bloco;

            List<String> subLista = linhas.subList(inicioBloco, fimBloco);

            Callable<Integer> tarefa = () -> contarNoBloco(subLista, palavraBuscada);

            resultados.add(executor.submit(tarefa));
        }

        int total = 0;
        for (Future<Integer> f : resultados) {
            try {
                total += f.get();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        executor.shutdown();

        long fim = System.currentTimeMillis();

        System.out.println(
                palavraBuscada + " - " + total +
                        " ocorrencias em " +
                        (fim - inicio) + " ms usando " +
                        numThreads + " threads\n"
        );

        return (int) (fim - inicio);
    }

    // --- Função CORRIGIDA ---
    private int contarNoBloco(List<String> bloco, String palavraBuscada) {
        int contador = 0;

        palavraBuscada = palavraBuscada.toLowerCase();

        for (String linha : bloco) {
            linha = linha.replaceAll("[^a-zA-Z0-9áéíóúàâêôãõçÁÉÍÓÚÀÂÊÔÃÕÇ ]", "")
                    .toLowerCase();

            String[] palavras = linha.split("\\s+");

            for (String p : palavras) {
                if (p.equals(palavraBuscada)) {
                    contador++;
                }
            }
        }

        return contador;
    }
}
