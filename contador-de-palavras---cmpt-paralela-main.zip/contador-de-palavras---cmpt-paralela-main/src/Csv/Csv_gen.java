package Csv;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Csv_gen {

    private final List<String> dados;

    public Csv_gen(List<String> dados) {
        this.dados = dados;
    }

    public void gerarCSV(String caminhoArquivo) {
        if (dados.size() % 3 != 0) {
            throw new IllegalArgumentException("A lista deve conter múltiplos de 3 elementos.");
        }

        try (FileWriter writer = new FileWriter(caminhoArquivo)) {
            writer.write("tipo_de_execucao,texto,tempo_ms\n");

            for (int i = 0; i < dados.size(); i += 3) {
                String tipo = dados.get(i);
                String texto = dados.get(i + 1);
                String tempo = dados.get(i + 2);

                writer.write(tipo + "," + texto + "," + tempo + "\n");
            }

            System.out.println("CSV gerado com sucesso em: " + caminhoArquivo);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
