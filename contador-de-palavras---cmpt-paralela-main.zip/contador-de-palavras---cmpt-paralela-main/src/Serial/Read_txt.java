package Serial;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Read_txt {

    public int lerArquivo(String caminhoArquivo, String palavraBuscada) {

        long inicio = System.currentTimeMillis();
        int contador = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(caminhoArquivo))) {

            String linha;
            while ((linha = br.readLine()) != null) {

                linha = linha.replaceAll("[^a-zA-Z0-9áéíóúàâêôãõçÁÉÍÓÚÀÂÊÔÃÕÇ ]", "")
                        .toLowerCase();

                String[] palavras = linha.split("\\s+");

                for (String palavra : palavras) {
                    if (palavra.equals(palavraBuscada.toLowerCase())) {
                        contador++;
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        }

        long fim = System.currentTimeMillis();

        System.out.println(palavraBuscada + " - " + contador + " ocorrencias em " + (fim - inicio) + " ms usando execução serial\n");

        return (int) (fim - inicio);
    }
}
